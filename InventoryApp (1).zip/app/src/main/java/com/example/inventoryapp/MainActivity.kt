package com.example.inventoryapp

import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import org.apache.poi.xssf.usermodel.XSSFWorkbook

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InventoryScreen()
        }
    }
}

@Composable
fun InventoryScreen() {
    var productName by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    val inventory = remember { mutableStateListOf<List<String>>() }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Inventario", style = MaterialTheme.typography.h5)

        BasicTextField(
            value = productName,
            onValueChange = { productName = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField -> 
                Box(Modifier.padding(8.dp)) { innerTextField() }
            }
        )
        BasicTextField(
            value = quantity,
            onValueChange = { quantity = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField -> 
                Box(Modifier.padding(8.dp)) { innerTextField() }
            }
        )
        BasicTextField(
            value = price,
            onValueChange = { price = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            decorationBox = { innerTextField -> 
                Box(Modifier.padding(8.dp)) { innerTextField() }
            }
        )

        Button(onClick = {
            inventory.add(listOf(productName, quantity, price))
            productName = ""
            quantity = ""
            price = ""
        }) {
            Text("Agregar Producto")
        }

        Button(onClick = { exportToExcel(inventory) }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Exportar a Excel")
        }
    }
}

fun exportToExcel(inventory: List<List<String>>) {
    val workbook = XSSFWorkbook()
    val sheet = workbook.createSheet("Inventario")

    val header = sheet.createRow(0)
    header.createCell(0).setCellValue("Producto")
    header.createCell(1).setCellValue("Cantidad")
    header.createCell(2).setCellValue("Precio")

    inventory.forEachIndexed { index, item ->
        val row = sheet.createRow(index + 1)
        row.createCell(0).setCellValue(item[0])
        row.createCell(1).setCellValue(item[1])
        row.createCell(2).setCellValue(item[2])
    }

    val file = File("/storage/emulated/0/Download/inventario.xlsx")
    file.outputStream().use { workbook.write(it) }
    workbook.close()
}
